//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by AntTweakBar.rc
//
#define IDC_CURSOR1                     101
#define IDC_CURSOR2                     102
#define IDC_CURSOR3                     103
#define IDC_CURSOR4                     104
#define IDC_CURSOR5                     105
#define IDC_CURSOR6                     106
#define IDC_CURSOR7                     107
#define IDC_CURSOR8                     108
#define IDC_CURSOR9                     109
#define IDC_CURSOR10                    110
#define IDC_CURSOR11                    111
#define IDC_CURSOR12                    112
#define IDC_CURSOR13                    113
#define IDC_CURSOR14                    114

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        115
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
